import { test, expect } from "bun:test";
import sum from './index.js';

// Suite pengujian untuk fungsi sum
test('suite pengujian fungsi sum', async () => {
  // Menguji penjumlahan dua bilangan positif
  test('harus bisa menjumlahkan dua bilangan positif dengan benar', () => {
    expect(sum(2, 3)).toBe(5);
    expect(sum(10, 5)).toBe(15);
    expect(sum(100, 200)).toBe(300);
  });

  // Menguji penanganan angka nol
  test('harus bisa menangani angka nol dengan benar', () => {
    expect(sum(0, 0)).toBe(0);
    expect(sum(5, 0)).toBe(5);
    expect(sum(0, 5)).toBe(5);
  });

  // Menguji penanganan bilangan negatif
  test('harus mengembalikan 0 ketika salah satu bilangan negatif', () => {
    expect(sum(-1, 5)).toBe(0);
    expect(sum(5, -1)).toBe(0);
    expect(sum(-1, -1)).toBe(0);
  });

  // Menguji input yang bukan angka
  test('harus mengembalikan 0 ketika input bukan angka', () => {
    expect(sum('2', 3)).toBe(0);
    expect(sum(2, '3')).toBe(0);
    expect(sum('a', 'b')).toBe(0);
    expect(sum(null, 5)).toBe(0);
    expect(sum(5, undefined)).toBe(0);
    expect(sum({}, [])).toBe(0);
  });

  // Menguji bilangan desimal
  test('harus bisa menangani bilangan desimal dengan benar', () => {
    expect(sum(1.5, 2.5)).toBe(4);
    expect(sum(0.1, 0.2)).toBe(0.3);
  });

  // Menguji bilangan yang sangat besar
  test('harus bisa menangani bilangan besar dengan benar', () => {
    expect(sum(Number.MAX_SAFE_INTEGER, 1)).toBe(Number.MAX_SAFE_INTEGER + 1);
  });
});