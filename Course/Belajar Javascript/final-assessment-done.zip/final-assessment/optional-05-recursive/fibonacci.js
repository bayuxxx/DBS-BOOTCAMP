function fibonacci(n) {
    let fibArray = [0];

    if (n >= 1) {
        fibArray.push(1);
    }

    for (let i = 2; i <= n; i++) {
        const nextNum = fibArray[i - 1] + fibArray[i - 2];
        fibArray.push(nextNum);
    }

    return fibArray;
}

// Jangan hapus kode di bawah ini!
export default fibonacci;
