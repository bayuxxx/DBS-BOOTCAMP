import "./js/components/app-header.js";
import "./js/components/note-list.js";
import "./js/components/note-form.js";
import "./style/main.css";

console.log("Aplikasi berhasil dijalankan!");
