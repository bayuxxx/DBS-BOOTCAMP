import { notesData } from "../data/notes-dummy.js";

class NotedList extends HTMLElement {
    #notes = [];
    #currentView = "active";

    constructor() {
        super();
        this.attachShadow({ mode: "open" });
        this.#initializeStyles();
    }

    #initializeStyles() {
        this.shadowRoot.innerHTML = `
        <style>
            :host {
                --primary-blue: #2196F3;
                --primary-light: #64B5F6;
                --primary-dark: #1976D2;
                --accent-blue: #0D47A1;
                --secondary-blue: #90CAF9;
                --background-light: #F5F9FF;
                --white: #FFFFFF;
                --text-primary: #333333;
                --text-secondary: #666666;
                --gray-100: #f8f9fa;
                --gray-200: #e9ecef;
                --shadow-sm: 0 2px 4px rgba(0, 0, 0, 0.1);
                display: block;
                margin-top: 80px;
            }
    
            .controls {
                position: sticky;
                top: 80px;
                display: flex;
                justify-content: center;
                gap: 1rem;
                margin: 2rem 0;
                padding: 1rem;
                flex-wrap: wrap;
                background-color: var(--background-light);
                z-index: 10;
            }
    
            button {
                font-family: 'Poppins', sans-serif;
                padding: 0.75rem 1.5rem;
                border: none;
                border-radius: 8px;
                cursor: pointer;
                transition: all 0.3s ease;
                font-weight: 500;
            }
    
            .add-button {
                background-color: var(--primary-blue);
                color: var(--white);
            }
            .add-button:hover {
                background-color: var(--primary-dark);
            }
    
            .category-button {
                background-color: var(--gray-100);
                color: var(--text-primary);
            }
            .category-button.active {
                background-color: var(--primary-light);
                color: var(--white);
            }
            .category-button:hover {
                background-color: var(--gray-200);
            }
            .category-button.active:hover {
                background-color: var(--primary-blue);
            }
    
            #notesList {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
                gap: 2rem;
                padding: 2rem;
                max-width: 1200px;
                margin: 0 auto;
            }
    
            .note-item {
                background-color: var(--white);
                border-radius: 12px;
                padding: 1.5rem;
                box-shadow: var(--shadow-sm);
                transition: transform 0.3s ease, box-shadow 0.3s ease;
                display: flex;
                flex-direction: column;
                gap: 1rem;
            }
            .note-item:hover {
                transform: translateY(-4px);
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
            }
    
            .note-title {
                color: var(--text-primary);
                font-size: 1.25rem;
                margin: 0;
                font-weight: 600;
            }
    
            .note-date {
                color: var(--text-secondary);
                font-size: 0.875rem;
                margin: 0;
            }
    
            .note-body {
                color: var(--text-primary);
                margin: 0;
                line-height: 1.5;
                flex-grow: 1;
                overflow: hidden;
                display: -webkit-box;
                -webkit-line-clamp: 3;
                -webkit-box-orient: vertical;
            }
    
            .archive-button, .unarchive-button {
                background-color: var(--secondary-blue);
                color: var(--text-primary);
                width: 100%;
                margin-top: auto;
            }
            .archive-button:hover, .unarchive-button:hover {
                background-color: var(--primary-light);
                color: var(--white);
            }
    
            .error-message {
                text-align: center;
                color: var(--text-primary);
                padding: 2rem;
                grid-column: 1 / -1;
            }
    
            @media (max-width: 768px) {
                :host {
                    margin-top: 70px;
                }
                .controls {
                    top: 70px;
                    flex-direction: column;
                    align-items: stretch;
                    padding: 1rem;
                    margin: 1rem 0;
                }
                #notesList {
                    grid-template-columns: 1fr;
                    padding: 1rem;
                    gap: 1rem;
                }
                .note-item {
                    margin: 0;
                }
            }
    
            @media (min-width: 769px) and (max-width: 1024px) {
                #notesList {
                    grid-template-columns: repeat(2, 1fr);
                    padding: 1.5rem;
                }
            }
        </style>
        <note-form-dialog></note-form-dialog>
        <div class="controls">
            <button class="add-button">Add Note</button>
            <button class="category-button active" data-view="active">Active Notes</button>
            <button class="category-button" data-view="archived">Archived Notes</button>
        </div>
        <div id="notesList"></div>
        `;
    }
    

    async connectedCallback() {
        try {
            await this.#loadNotes();
            this.#addControlEventListeners();
            this.#render();
        } catch (error) {
            console.error("Error loading notes:", error);
            this.#renderError();
        }
    }

    async #loadNotes() {
        this.#notes = notesData;
    }

    #addControlEventListeners() {
        const addButton = this.shadowRoot.querySelector(".add-button");
        const categoryButtons =
            this.shadowRoot.querySelectorAll(".category-button");
        const noteFormDialog = this.shadowRoot.querySelector("note-form-dialog");

        // Add Note button click handler
        addButton.addEventListener("click", () => {
            noteFormDialog.open();
        });

        // Note form submission handler
        noteFormDialog.addEventListener("note-submitted", (e) => {
            this.#notes.unshift(e.detail);
            this.#render();
        });

        // Category buttons handlers (remain the same)
        categoryButtons.forEach((button) => {
            button.addEventListener("click", (e) => {
                categoryButtons.forEach((btn) => btn.classList.remove("active"));
                button.classList.add("active");
                this.#currentView = e.target.dataset.view;
                this.#render();
            });
        });
    }

    #render() {
        const notesContainer = this.shadowRoot.querySelector("#notesList");
        const filteredNotes = this.#notes.filter((note) =>
            this.#currentView === "active" ? !note.archived : note.archived
        );

        notesContainer.innerHTML = filteredNotes
            .map((note) => this.#createNoteItemElement(note))
            .join("");

        this.#addEventListeners();
    }

    #renderError() {
        const notesContainer = this.shadowRoot.querySelector("#notesList");
        notesContainer.innerHTML = `
            <div class="error-message">
                Failed to load notes. Please try again later.
            </div>
        `;
    }

    #createNoteItemElement({ id, title, body, createdAt, archived }) {
        const date = new Date(createdAt).toLocaleDateString("en-US", {
            year: "numeric",
            month: "long",
            day: "numeric",
        });

        const actionButton = archived
            ? `<button class="unarchive-button" data-id="${id}">Unarchive</button>`
            : `<button class="archive-button" data-id="${id}">Archive</button>`;

        return `
            <div class="note-item" data-noteid="${id}">
                <h3 class="note-title">${title}</h3>
                <p class="note-date">${date}</p>
                <p class="note-body">${body}</p>
                ${actionButton}
            </div>
        `;
    }

    #addEventListeners() {
        const archiveButtons = this.shadowRoot.querySelectorAll(".archive-button");
        const unarchiveButtons =
            this.shadowRoot.querySelectorAll(".unarchive-button");

        archiveButtons.forEach((button) => {
            button.addEventListener("click", (e) => {
                const noteId = e.target.dataset.id;
                this.#archiveNote(noteId);
            });
        });

        unarchiveButtons.forEach((button) => {
            button.addEventListener("click", (e) => {
                const noteId = e.target.dataset.id;
                this.#unarchiveNote(noteId);
            });
        });
    }

    #archiveNote(noteId) {
        const noteIndex = this.#notes.findIndex((note) => note.id === noteId);
        if (noteIndex !== -1) {
            this.#notes[noteIndex].archived = true;
            this.#render();
        }
    }

    #unarchiveNote(noteId) {
        const noteIndex = this.#notes.findIndex((note) => note.id === noteId);
        if (noteIndex !== -1) {
            this.#notes[noteIndex].archived = false;
            this.#render();
        }
    }
}

customElements.define("noted-list", NotedList);
